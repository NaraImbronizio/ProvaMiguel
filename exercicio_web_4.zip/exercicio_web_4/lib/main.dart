import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'
    show SharedPreferences;

// ---------------- Classe Tarefa ----------------
class Tarefa {
  int id;
  String titulo;
  String descricao;
  bool concluida;
  DateTime dataCriacao;

  Tarefa({
    required this.id,
    required this.titulo,
    this.descricao = '',
    this.concluida = false,
    DateTime? dataCriacao,
  }) : dataCriacao = dataCriacao ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'titulo': titulo,
      'descricao': descricao,
      'concluida': concluida,
      'dataCriacao': dataCriacao.toIso8601String(),
    };
  }

  factory Tarefa.fromMap(Map<String, dynamic> map) {
    return Tarefa(
      id: map['id'],
      titulo: map['titulo'],
      descricao: map['descricao'] ?? '',
      concluida: map['concluida'] ?? false,
      dataCriacao: DateTime.parse(map['dataCriacao']),
    );
  }
}

// ---------------- Gerenciador de Tarefas ----------------
class GerenciadorTarefas extends ChangeNotifier {
  List<Tarefa> _tarefas = [];
  static const String chaveTarefas = 'tarefas';

  List<Tarefa> get tarefas => List.unmodifiable(_tarefas);

  GerenciadorTarefas() {
    carregarTarefas();
  }

  Future<void> carregarTarefas() async {
    final prefs = await SharedPreferences.getInstance();
    final String? tarefasJson = prefs.getString(chaveTarefas);
    if (tarefasJson != null) {
      List<dynamic> listaMap = jsonDecode(tarefasJson);
      _tarefas = listaMap.map((map) => Tarefa.fromMap(map)).toList();
      notifyListeners();
    }
  }

  Future<void> salvarTarefas() async {
    final prefs = await SharedPreferences.getInstance();
    List<Map<String, dynamic>> listaMap = _tarefas
        .map((t) => t.toMap())
        .toList();
    await prefs.setString(chaveTarefas, jsonEncode(listaMap));
  }

  void adicionarTarefa(Tarefa tarefa) {
    _tarefas.add(tarefa);
    salvarTarefas();
    notifyListeners();
  }

  void removerTarefa(int id) {
    _tarefas.removeWhere((t) => t.id == id);
    salvarTarefas();
    notifyListeners();
  }

  void marcarConcluida(int id) {
    final tarefa = _tarefas.firstWhere((t) => t.id == id);
    tarefa.concluida = !tarefa.concluida;
    salvarTarefas();
    notifyListeners();
  }

  void editarTarefa(int id, {String? titulo, String? descricao}) {
    final tarefa = _tarefas.firstWhere((t) => t.id == id);
    if (titulo != null) tarefa.titulo = titulo;
    if (descricao != null) tarefa.descricao = descricao;
    salvarTarefas();
    notifyListeners();
  }

  List<Tarefa> filtrarTarefas(String status) {
    switch (status) {
      case 'pendentes':
        return _tarefas.where((t) => !t.concluida).toList();
      case 'concluidas':
        return _tarefas.where((t) => t.concluida).toList();
      default:
        return _tarefas;
    }
  }
}

// ---------------- App Flutter ----------------
void main() {
  runApp(MaterialApp(home: ListaTarefasPage()));
}

class ListaTarefasPage extends StatefulWidget {
  @override
  _ListaTarefasPageState createState() => _ListaTarefasPageState();
}

class _ListaTarefasPageState extends State<ListaTarefasPage> {
  final GerenciadorTarefas gerenciador = GerenciadorTarefas();
  String filtro = 'todas';

  final TextEditingController tituloController = TextEditingController();
  final TextEditingController descricaoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Lista de Tarefas'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) => setState(() => filtro = value),
            itemBuilder: (context) => [
              PopupMenuItem(value: 'todas', child: Text('Todas')),
              PopupMenuItem(value: 'pendentes', child: Text('Pendentes')),
              PopupMenuItem(value: 'concluidas', child: Text('Concluídas')),
            ],
          ),
        ],
      ),
      body: FutureBuilder(
        future: gerenciador.carregarTarefas(),
        builder: (context, snapshot) {
          final tarefasFiltradas = gerenciador.filtrarTarefas(filtro);
          return ListView.builder(
            itemCount: tarefasFiltradas.length,
            itemBuilder: (context, index) {
              final tarefa = tarefasFiltradas[index];
              return ListTile(
                title: Text(
                  tarefa.titulo,
                  style: TextStyle(
                    decoration: tarefa.concluida
                        ? TextDecoration.lineThrough
                        : null,
                  ),
                ),
                subtitle: tarefa.descricao.isNotEmpty
                    ? Text(tarefa.descricao)
                    : null,
                leading: Checkbox(
                  value: tarefa.concluida,
                  onChanged: (_) =>
                      setState(() => gerenciador.marcarConcluida(tarefa.id)),
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit),
                      onPressed: () => _abrirFormulario(tarefa: tarefa),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete),
                      onPressed: () =>
                          setState(() => gerenciador.removerTarefa(tarefa.id)),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _abrirFormulario(),
        child: Icon(Icons.add),
      ),
    );
  }

  void _abrirFormulario({Tarefa? tarefa}) {
    if (tarefa != null) {
      tituloController.text = tarefa.titulo;
      descricaoController.text = tarefa.descricao;
    } else {
      tituloController.clear();
      descricaoController.clear();
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(tarefa == null ? 'Nova Tarefa' : 'Editar Tarefa'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: tituloController,
              decoration: InputDecoration(labelText: 'Título'),
            ),
            TextField(
              controller: descricaoController,
              decoration: InputDecoration(labelText: 'Descrição'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                if (tarefa == null) {
                  final novoId = gerenciador.tarefas.isEmpty
                      ? 1
                      : gerenciador.tarefas
                                .map((t) => t.id)
                                .reduce((a, b) => a > b ? a : b) +
                            1;
                  gerenciador.adicionarTarefa(
                    Tarefa(
                      id: novoId,
                      titulo: tituloController.text,
                      descricao: descricaoController.text,
                    ),
                  );
                } else {
                  gerenciador.editarTarefa(
                    tarefa.id,
                    titulo: tituloController.text,
                    descricao: descricaoController.text,
                  );
                }
              });
              Navigator.pop(context);
            },
            child: Text('Salvar'),
          ),
        ],
      ),
    );
  }
}
