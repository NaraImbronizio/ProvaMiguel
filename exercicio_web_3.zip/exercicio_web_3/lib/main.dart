import 'package:flutter/material.dart';

void main() {
  runApp(const IMCApp());
}

class IMCApp extends StatelessWidget {
  const IMCApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Calculadora de IMC',
      home: Scaffold(
        appBar: AppBar(title: const Text('Calculadora de IMC')),
        body: const IMCScreen(),
      ),
    );
  }
}

class IMCScreen extends StatefulWidget {
  const IMCScreen({super.key});

  @override
  State<IMCScreen> createState() => _IMCScreenState();
}

class _IMCScreenState extends State<IMCScreen> {
  final pesoController = TextEditingController();
  final alturaController = TextEditingController();

  String resultado = '';

  void calcular() {
    double? peso = double.tryParse(pesoController.text);
    double? altura = double.tryParse(alturaController.text);

    if (peso == null || peso <= 0) {
      setState(() {
        resultado = 'Peso inválido!';
      });
      return;
    }

    if (altura == null || altura <= 0) {
      setState(() {
        resultado = 'Altura inválida!';
      });
      return;
    }

    double imc = peso / (altura * altura);
    String classificacao = classificarIMC(imc);

    setState(() {
      resultado =
          'IMC: ${imc.toStringAsFixed(2)}\nClassificação: $classificacao';
    });
  }

  String classificarIMC(double imc) {
    if (imc < 18.5) return 'Abaixo do peso';
    if (imc < 25) return 'Normal';
    if (imc < 30) return 'Sobrepeso';
    return 'Obesidade';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        children: [
          TextField(
            controller: pesoController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Peso (kg)'),
          ),
          TextField(
            controller: alturaController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'Altura (m)'),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: calcular,
            child: const Text('Calcular IMC'),
          ),
          const SizedBox(height: 20),
          Text(resultado, style: const TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}
