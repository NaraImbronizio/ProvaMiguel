package com.example.exercicio_web_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
