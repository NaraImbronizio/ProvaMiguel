package com.example.exercicio_web_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
