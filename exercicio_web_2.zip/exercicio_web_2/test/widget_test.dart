import 'package:flutter_test/flutter_test.dart';
import 'package:exercicio_web_2/main.dart'; // ajuste conforme o nome real do arquivo

void main() {
  testWidgets('Contador increments smoke test', (WidgetTester tester) async {
    // Monta o app
    await tester.pumpWidget(ContadorInteligenteApp());

    // Verifica que o contador começa em 0
    expect(find.text('0'), findsOneWidget);
    expect(find.text('1'), findsNothing);

    // Toca no botão '+1' e atualiza a UI
    await tester.tap(find.text('+1'));
    await tester.pump();

    // Verifica que o contador incrementou para 1
    expect(find.text('0'), findsNothing);
    expect(find.text('1'), findsOneWidget);

    // Toca no botão '+5' e atualiza a UI
    await tester.tap(find.text('+5'));
    await tester.pump();

    // Verifica que o contador incrementou para 6
    expect(find.text('6'), findsOneWidget);
  });
}
