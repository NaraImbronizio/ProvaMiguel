import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // Para vibração
// Caso queira som, pode usar o pacote audioplayers

void main() {
  runApp(const ContadorInteligenteApp());
}

class ContadorInteligenteApp extends StatelessWidget {
  const ContadorInteligenteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contador Inteligente',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const ContadorPage(),
    );
  }
}

class ContadorPage extends StatefulWidget {
  const ContadorPage({super.key});

  @override
  State<ContadorPage> createState() => _ContadorPageState();
}

class _ContadorPageState extends State<ContadorPage> {
  int _contador = 0;
  String _mensagem = "";

  void _atualizarContador(int valor) {
    setState(() {
      _contador += valor;
      if (_contador < 0) {
        _contador = 0; // não deixa negativo
      }

      // Verifica marcos para vibrar
      if (_contador == 10 || _contador == 50 || _contador == 100) {
        HapticFeedback.mediumImpact();
      }

      // Mensagem especial quando chega a 100
      if (_contador == 100) {
        _mensagem = "🎉 Parabéns! Você chegou a 100!";
      } else {
        _mensagem = "";
      }
    });
  }

  void _resetar() {
    setState(() {
      _contador = 0;
      _mensagem = "";
    });
  }

  Color _corNumero() {
    if (_contador == 0) {
      return Colors.red;
    } else {
      return Colors.green;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Contador Inteligente"),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "$_contador",
              style: TextStyle(
                fontSize: 80,
                fontWeight: FontWeight.bold,
                color: _corNumero(),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              _mensagem,
              style: const TextStyle(fontSize: 20, color: Colors.blueAccent),
            ),
            const SizedBox(height: 40),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                ElevatedButton(
                  onPressed: () => _atualizarContador(1),
                  child: const Text("+1"),
                ),
                ElevatedButton(
                  onPressed: () => _atualizarContador(-1),
                  child: const Text("-1"),
                ),
                ElevatedButton(
                  onPressed: () => _atualizarContador(5),
                  child: const Text("+5"),
                ),
                ElevatedButton(
                  onPressed: () => _atualizarContador(-5),
                  child: const Text("-5"),
                ),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _resetar,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
              ),
              child: const Text("Resetar"),
            ),
          ],
        ),
      ),
    );
  }
}
